package com.csw.json.xml.controller;

import java.io.File;
import java.io.IOException;

import com.csw.json.xml.converters.factory.ConverterFactory;

public class JSONtoXMLMainClass {


    public static void main(String[] args) throws IOException
    {

    	     File jsonFile   =new File("C:/RiskSense/JsonToXmlConversion/src/main/java/com/csw/json/xml/convert/files/example.json");
    	     File xmlFile =new File("C:/RiskSense/JsonToXmlConversion/src/main/java/com/csw/json/xml/convert/files/example.xml");
    	     ConverterFactory.createXMLJSONConverter(jsonFile,xmlFile);

    }
    
}
