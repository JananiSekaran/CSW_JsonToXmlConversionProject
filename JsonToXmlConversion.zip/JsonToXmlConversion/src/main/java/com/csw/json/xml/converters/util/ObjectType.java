package com.csw.json.xml.converters.util;

import org.json.JSONArray;
import org.json.JSONObject;

public class ObjectType {

	public static Object getObjectType(Object value) {
		Object result = null;
		if (value.equals(null)) {
			result = Constant.NULL;
		} else if (value instanceof String) {
			result = Constant.STRING;
		} else if (value instanceof Boolean) {
			result = Constant.BOOLEAN;
		} else if (value instanceof Integer || value instanceof Float || value instanceof Double
				|| value instanceof Long) {
			result = Constant.NUMBER;
		} else if (value instanceof JSONArray) {
			result = Constant.ARRAY;
		} else if (value instanceof JSONObject) {
			result = Constant.OBJECT;

		}

		return result;
	}



}
