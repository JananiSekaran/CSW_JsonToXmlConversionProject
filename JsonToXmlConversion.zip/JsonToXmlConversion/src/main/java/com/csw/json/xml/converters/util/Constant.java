package com.csw.json.xml.converters.util;

public class Constant {

    public static final String OBJECT="object";
    public static final String NAME="name";
    public static final String ARRAY="array";
    public static final String NULL="null";
    public static final String EMPTY_STRING="";
    public static final String NUMBER = "number";
    public static final String BOOLEAN = "boolean";
    public static final String STRING = "string";


}
