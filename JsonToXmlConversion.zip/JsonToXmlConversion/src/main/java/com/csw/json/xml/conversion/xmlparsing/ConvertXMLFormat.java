package com.csw.json.xml.conversion.xmlparsing;

import org.json.JSONException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.csw.json.xml.converters.util.Constant;
import com.csw.json.xml.converters.util.ObjectType;

public class ConvertXMLFormat {



    public static ObjectType objectType;
    
    public static void iterateJSONArray(Document document, Element user, String key, Object value)
            throws JSONException {
        Object result;
        org.json.JSONArray jsonArray =new org.json.JSONArray(value.toString());

        Element arrayElement = document.createElement(Constant.ARRAY);
        user.appendChild(arrayElement);
        arrayElement.setAttribute(Constant.NAME, key);

        for(int temp=0;temp<jsonArray.length();temp++)
        {
            result = ObjectType.getObjectType(jsonArray.get(temp));
            if(!result.equals(Constant.OBJECT) && !result.equals(Constant.ARRAY)) {
                xmlFormatConversion(document, arrayElement, Constant.EMPTY_STRING, jsonArray.get(temp), result);
            }
            else if(result.equals(Constant.ARRAY)){

                iterateJSONArray(document, arrayElement, key, jsonArray.get(temp));

            }
            else
            {
                xmlFormatConversion(document, arrayElement, key, jsonArray.get(temp), result);

            }

        }


    }



    public static void xmlFormatConversion(Document document, Element user, String key, Object value, Object result) throws JSONException {
        Element element = document.createElement(result.toString());
        if (!key.equals(Constant.EMPTY_STRING)) {
            if (!user.getNodeName().equals(Constant.ARRAY)) {
                element.setAttribute(Constant.NAME, key);
            }
            if (result.equals(Constant.OBJECT)) {
                org.json.JSONObject jobject = new org.json.JSONObject(value.toString());

                for (int temp = 0; jobject.names()!=null && temp < jobject.names().length(); temp++) {
                    key = jobject.names().getString(temp);
                    value = jobject.get(jobject.names().getString(temp));
                    result = ObjectType.getObjectType(value);
                    if(!result.equals(Constant.ARRAY))
                    {
                        xmlFormatConversion(document, element, key, value, result);
                    }
                    else
                    {
                        iterateJSONArray(document,element,key,value);

                    }

                }
                value = null;

            }


        }
        if (value != null) {
            element.appendChild(document.createTextNode(value.toString()));
        }
        user.appendChild(element);
    }





}
