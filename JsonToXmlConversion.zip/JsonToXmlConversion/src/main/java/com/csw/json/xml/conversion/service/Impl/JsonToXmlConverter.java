package com.csw.json.xml.conversion.service.Impl;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.csw.converters.transformer.XMLTransformer;
import com.csw.json.xml.conversion.xmlparsing.ConvertXMLFormat;
import com.csw.json.xml.converters.factory.XMLJSONConverterI;
import com.csw.json.xml.converters.util.Constant;
import com.csw.json.xml.converters.util.ObjectType;
import com.fasterxml.jackson.databind.ObjectMapper;

public class JsonToXmlConverter implements XMLJSONConverterI{

    public static XMLTransformer xmlTransformer;
    public static ConvertXMLFormat convertXMLFormat;
    public static ObjectType objectType;

    public void convertJSONtoXML(File json, File xml) throws IOException {
        String inputPath = json.getPath();
        String outputPath = xml.getPath();

        byte[] mapData = Files.readAllBytes(Paths.get(inputPath));
        Map<Object,Object> linkedHashMap ;

        ObjectMapper objectMapper = new ObjectMapper();

        linkedHashMap = objectMapper.readValue(mapData, LinkedHashMap.class);
        Set entrySet = linkedHashMap.entrySet();

        JSONArray orderedJson=new JSONArray();
        Iterator iterator = entrySet.iterator();
        while (iterator.hasNext()) {
            Map.Entry me = (Map.Entry)iterator.next();
            JSONObject tmpJson=new JSONObject ();
            tmpJson.put(me.getKey(),me.getValue());
            orderedJson.add(tmpJson);
        }
        try {
            customXMLFormat(orderedJson, outputPath);
        } catch (Exception e) {
            e.printStackTrace();
        }

    }


    public static void customXMLFormat(JSONArray jsonArray, String outputPath) throws ParserConfigurationException, TransformerException {
        DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();

        Document document = dBuilder.newDocument();

        Element user = document.createElement(Constant.OBJECT);
        document.appendChild(user);
        for (int i = 0; i < jsonArray.size(); i++) {

            JSONObject json = (JSONObject)jsonArray.get(i);
            org.json.JSONObject jsonObject = new org.json.JSONObject(json.toJSONString());


            for (Object key : jsonObject.keySet()) {

                String keyStr = (String) key;
                Object value = jsonObject.get(keyStr);
                Object result = objectType.getObjectType(value);

                if (result.equals(Constant.ARRAY)) {

                    convertXMLFormat.iterateJSONArray(document, user, keyStr, value);


                }
                else {
                    Object  valueTemp=(!result.equals(Constant.NULL))? value : Constant.EMPTY_STRING ;
                        convertXMLFormat.xmlFormatConversion(document, user, keyStr, valueTemp, result);


                }

            }

        }

        xmlTransformer.transformToXML(outputPath, document);

    }




}
