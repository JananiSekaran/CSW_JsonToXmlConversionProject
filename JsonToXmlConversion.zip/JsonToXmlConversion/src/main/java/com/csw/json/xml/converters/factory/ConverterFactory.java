package com.csw.json.xml.converters.factory;

import java.io.File;
import java.io.IOException;

import com.csw.json.xml.conversion.service.Impl.JsonToXmlConverter;

public class ConverterFactory {


    /**
     * You should implement this method having it return your version of
     * {@link com.csw.json.xml.converters.factory.XMLJSONConverterI}.
     *
     * @return {@link com.csw.json.xml.converters.factory.XMLJSONConverterI} implementation you created.
     */
    public static final XMLJSONConverterI createXMLJSONConverter(File jsonFile,File xmlFile) throws IOException {

        XMLJSONConverterI xmlJsonConverter=new JsonToXmlConverter();
        xmlJsonConverter.convertJSONtoXML(jsonFile,xmlFile);
        return xmlJsonConverter;
    }

}
